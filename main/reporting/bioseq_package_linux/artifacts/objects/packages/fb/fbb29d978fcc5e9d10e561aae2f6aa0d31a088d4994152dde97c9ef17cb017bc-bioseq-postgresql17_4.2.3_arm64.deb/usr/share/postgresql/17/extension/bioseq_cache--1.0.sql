-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION bioseq_cache" to load this file. \quit

CREATE FUNCTION bioseq_cache.entries()
RETURNS TABLE (entry_key text, generation bigint, kind text, state text, database_oid oid, owner_role oid, producer_pid integer, created_at timestamptz, completed_at timestamptz, age interval, ttl interval, rows bigint, logical_bytes bigint, stored_bytes bigint, waiters integer, readers integer, hits bigint, sql text, producer_plan text, dependencies jsonb)
AS 'MODULE_PATHNAME', 'entries'
LANGUAGE C
VOLATILE
PARALLEL RESTRICTED
SECURITY INVOKER
CALLED ON NULL INPUT;

CREATE FUNCTION bioseq_cache.invalidate_all()
RETURNS bigint
AS 'MODULE_PATHNAME', 'invalidate_all'
LANGUAGE C
VOLATILE
PARALLEL UNSAFE
SECURITY INVOKER
STRICT;

CREATE FUNCTION bioseq_cache.invalidate_relation(relation_oid regclass)
RETURNS bigint
AS 'MODULE_PATHNAME', 'invalidate_relation'
LANGUAGE C
VOLATILE
PARALLEL UNSAFE
SECURITY INVOKER
STRICT;

CREATE FUNCTION bioseq_cache.reset_stats()
RETURNS void
AS 'MODULE_PATHNAME', 'reset_stats'
LANGUAGE C
VOLATILE
PARALLEL UNSAFE
SECURITY INVOKER
STRICT;

CREATE FUNCTION bioseq_cache.stats()
RETURNS TABLE (produced bigint, completed_hits bigint, inflight_waits bigint, reuse_hits bigint, fallbacks bigint, invalidations bigint, evictions bigint, logical_bytes bigint, stored_bytes bigint)
AS 'MODULE_PATHNAME', 'stats'
LANGUAGE C
VOLATILE
PARALLEL RESTRICTED
SECURITY INVOKER
CALLED ON NULL INPUT;

CREATE FUNCTION bioseq_cache.version()
RETURNS text
AS 'MODULE_PATHNAME', 'version'
LANGUAGE C
IMMUTABLE
PARALLEL SAFE
SECURITY INVOKER
STRICT;

GRANT EXECUTE ON FUNCTION bioseq_cache.entries() TO pg_read_all_stats;

GRANT EXECUTE ON FUNCTION bioseq_cache.stats() TO pg_read_all_stats;

GRANT EXECUTE ON FUNCTION bioseq_cache.version() TO pg_read_all_stats;

GRANT USAGE ON SCHEMA bioseq_cache TO pg_read_all_stats;

REVOKE ALL ON FUNCTION bioseq_cache.entries() FROM PUBLIC;

REVOKE ALL ON FUNCTION bioseq_cache.invalidate_all() FROM PUBLIC;

REVOKE ALL ON FUNCTION bioseq_cache.invalidate_relation(regclass) FROM PUBLIC;

REVOKE ALL ON FUNCTION bioseq_cache.reset_stats() FROM PUBLIC;

REVOKE ALL ON FUNCTION bioseq_cache.stats() FROM PUBLIC;

REVOKE ALL ON SCHEMA bioseq_cache FROM PUBLIC;

REVOKE CREATE ON SCHEMA bioseq_cache FROM PUBLIC;
